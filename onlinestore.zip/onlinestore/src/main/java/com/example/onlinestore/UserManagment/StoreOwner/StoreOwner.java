package com.example.onlinestore.UserManagment.StoreOwner;

import com.example.onlinestore.UserManagment.User;

import javax.persistence.Entity;

@Entity
public class StoreOwner extends User {
}
