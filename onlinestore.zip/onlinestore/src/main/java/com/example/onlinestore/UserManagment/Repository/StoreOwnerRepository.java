package com.example.onlinestore.UserManagment.Repository;

import com.example.onlinestore.UserManagment.Model.StoreOwner;
import org.springframework.data.repository.CrudRepository;

public interface StoreOwnerRepository extends CrudRepository<StoreOwner, String> {

}
