package com.example.onlinestore.UserManagment.Buyer;

import org.springframework.data.repository.CrudRepository;

public interface BuyerRepository extends CrudRepository<Buyer, Integer> {

}
