package com.example.onlinestore.UserManagment.StoreOwner;

import org.springframework.data.repository.CrudRepository;

public interface StoreOwnerRepository extends CrudRepository<StoreOwner, Integer> {

}
