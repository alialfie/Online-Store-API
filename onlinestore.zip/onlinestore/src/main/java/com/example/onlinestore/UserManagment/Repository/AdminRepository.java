package com.example.onlinestore.UserManagment.Repository;

import com.example.onlinestore.UserManagment.Model.Admin;
import org.springframework.data.repository.CrudRepository;

public interface AdminRepository extends CrudRepository<Admin, String> {
}
