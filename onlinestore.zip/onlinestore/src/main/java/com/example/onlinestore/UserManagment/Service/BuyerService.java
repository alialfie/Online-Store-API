package com.example.onlinestore.UserManagment.Service;

public class BuyerService {
    public boolean checkValidation(String Address)
    {
        return true;
    }
}
