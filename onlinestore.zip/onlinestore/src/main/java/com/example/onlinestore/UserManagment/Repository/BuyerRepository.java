package com.example.onlinestore.UserManagment.Repository;

import com.example.onlinestore.UserManagment.Model.Buyer;
import org.springframework.data.repository.CrudRepository;

public interface BuyerRepository extends CrudRepository<Buyer, String> {

}
